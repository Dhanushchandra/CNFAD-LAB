package com.cnfad.lab1;

public class Ticket {
	
	private int ticno, price, seatno;
	private String tictype;
	public int getTicno() {
		return ticno;
	}
	public void setTicno(int ticno) {
		this.ticno = ticno;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getSeatno() {
		return seatno;
	}
	public void setSeatno(int seatno) {
		this.seatno = seatno;
	}
	public String getTictype() {
		return tictype;
	}
	public void setTictype(String tictype) {
		this.tictype = tictype;
	}

}
